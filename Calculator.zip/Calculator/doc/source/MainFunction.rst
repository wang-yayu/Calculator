MainFunction module
===================

.. automodule:: MainFunction
   :members:
   :undoc-members:
   :show-inheritance:
